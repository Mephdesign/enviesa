const flkty = new Flickity('.carousel', {
	cellAlign: 'left',
	contain: true,
	autoPlay: true,
});
